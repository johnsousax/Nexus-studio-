---
name: nexus-studio
description: Estúdio criativo Nexus Studio. Cria motion graphics (EffectCraft, After Effects open source), edita vídeo, Reels e legendas (FilmCraft, Premiere open source) e faz flyers e criativos a partir de PSD (PhotoCraft, Photoshop open source) direto no ambiente do Claude, inclusive pelo celular. Use quando o usuário pedir motion, intro, vídeo animado, Reels, corte, legenda, flyer, criativo, anúncio, PSD ou variações em lote.
---

# Nexus Studio (no ambiente do Claude)

PhotoCraft, FilmCraft e EffectCraft são apps open source da ArtCraft/Storytold (MIT/Apache, em alpha) com linha de comando. Aqui eles rodam sem tela, pelo Bash, e o resultado vai para o usuário com SendUserFile.

## 1. Preparar (uma vez por sessão, uns 15 s)

```bash
export NEXUS_DIR="${NEXUS_DIR:-/opt/nexus-studio}"
if [ ! -x "$NEXUS_DIR/bin/effectcraft-cli" ] || [ ! -x "$NEXUS_DIR/bin/filmcraft-cli" ] || [ ! -x "$NEXUS_DIR/bin/photocraft-cli" ]; then
  mkdir -p "$NEXUS_DIR/bin"
  case "$(uname -m)" in aarch64|arm64) ARCH=aarch64 ;; *) ARCH=x86_64 ;; esac
  for app in effectcraft filmcraft photocraft; do
    tag="$(git ls-remote --tags --refs "https://github.com/storytold/$app.git" | awk -F/ '{print $3}' | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -1)"
    file="$app-${tag#v}-linux-$ARCH.tar.gz"; base="https://github.com/storytold/$app/releases/download/$tag"; tmp="$(mktemp -d)"
    curl -fsSL --retry 3 -o "$tmp/$file" "$base/$file" && curl -fsSL --retry 3 -o "$tmp/SHA256SUMS.txt" "$base/SHA256SUMS.txt"
    (cd "$tmp" && grep " $file\$" SHA256SUMS.txt | sha256sum -c - >/dev/null) || { echo "checksum invalido: $file"; exit 1; }
    mkdir -p "$NEXUS_DIR/$app" && tar -xzf "$tmp/$file" -C "$NEXUS_DIR/$app" --strip-components=1
    ln -sf "$NEXUS_DIR/$app/bin/$app-cli" "$NEXUS_DIR/bin/$app-cli"; rm -rf "$tmp"; echo "$app $tag ok"
  done
fi
export PATH="$NEXUS_DIR/bin:$PATH"
mkdir -p nexus/entrada nexus/projetos nexus/saidas
```

Se `/opt` não tiver permissão de escrita, use `NEXUS_DIR=$HOME/.nexus-studio`. Os arquivos que o usuário anexar entram em `nexus/entrada/` (copie, nunca edite o original).

## 2. Regras de ouro

- **Descubra antes de usar**: `effectcraft-cli commands --filter X`, `filmcraft-cli commands X` / `filmcraft-cli describe ID`, `photocraft-cli commands --filter X`. Parâmetro desconhecido volta como erro com a lista dos aceitos: corrija com base nele.
- **Olhe antes de entregar**: renderize quadros em PNG e abra com Read. Confira enquadramento, legibilidade, texto cortado e área segura (Reels: nada essencial nos 250 px de cima nem nos 350 px de baixo).
- **Padrão de qualidade**: motion a **60 fps com motion blur**, cada elemento animado separadamente com easing forte, entradas escalonadas e acabamento extremamente profissional. Antes de criar um motion, **pergunte o assunto e o estilo de design** (AskUserQuestion: minimal Apple-like, tipográfico cinético, neon/tech roxo-azul-preto, festa/evento, corporativo).
- **Identidade**: use a marca do usuário (logo, cores e fontes anexados na conversa). Se não houver, peça uma vez antes de criar. Peças de clientes usam a identidade do cliente.
- **Formatos**: Reels/Stories 1080x1920, feed 1080x1350 ou 1080x1080, horizontal 1920x1080.
- **Entrega**: MP4 H.264 e PNG/JPG via SendUserFile, mais o projeto editável (`.ecproj`/`.fcproj`) quando útil. A sessão é temporária, então envie tudo o que importa.

## 3. Motion (EffectCraft)

`effectcraft-cli run <proj.ecproj | --empty> <cmd> '<json>' <cmd> '<json>' ... --save-as P.ecproj --json` executa comandos em sequência. Para continuar um projeto: `effectcraft-cli run P.ecproj ... --save`.

Testado nesta versão:
```bash
effectcraft-cli run --empty \
  comp.new '{"name":"Main","width":1080,"height":1920,"frameRate":60,"duration":8}' \
  layer.newSolid '{"color":"#0b0614","name":"Fundo"}' \
  layer.newText '{"text":"OFERTA","size":180,"fill":"#ffffff","name":"Headline"}' \
  prop.addKey '{"layer":"Headline","path":"transform/scale","time":1.0,"value":[80,80]}' \
  prop.addKey '{"layer":"Headline","path":"transform/scale","time":1.5,"value":[100,100]}' \
  keys.select '{"keys":[{"layer":"Headline","path":"transform/scale","time":1.0},{"layer":"Headline","path":"transform/scale","time":1.5}]}' \
  keys.easyEase '{}' \
  comp.setSwitch '{"switch":"motionBlur","value":true}' \
  layer.setSwitch '{"layers":["Headline"],"switch":"motionBlur","value":true}' \
  --save-as nexus/projetos/promo.ecproj --json
effectcraft-cli render-frame nexus/projetos/promo.ecproj --time 1.2 --max-side 720 --out nexus/saidas/q1.png --json
effectcraft-cli render nexus/projetos/promo.ecproj --comp Main --out nexus/saidas/promo.mp4
```

Fluxo:
1. Roteiro curto (cenas, tempos, o que cada elemento faz) mostrado ao usuário antes de montar.
2. Elementos com `name`: `layer.newText` (fonte: `text.fonts {"query":..}` e depois `layer.setText {"layer","font","style"}`), `layer.newShape {"kind":...}` + `layer.addShapeItem` (trim, repeater, gradiente), `layer.newSolid`, imagens com `file.import {"paths":[abs]}` + `layer.addItem`, `layer.newNull` para parenting.
3. Animação: `prop.addKey` (layer seconds; `timeBase:"comp"` para tempo da comp), `keys.easyEase`, curvas fortes com `keys.setEase {..."influence":80}` ou `keys.velocity`, escalonamento de 0.06 a 0.12 s (`layer.timing` / `layer.quickOffset`), overshoot com 3 keys (100→112→100). Shutter: `comp.settings {"shutterAngle":180}`.
4. Efeitos: `effect.apply {"layer","effect":"Glow"}` e `prop.set {"layer","path":"effects/#1/...","value"}` (`effectcraft-cli props <proj> <comp> <layer>` lista os paths).
5. Para muitos elementos: `effectcraft-cli script arquivo.jsx P.ecproj --save` (API de scripting do After Effects; `app.run(id, params)` chama qualquer comando).
6. Quadros de checagem com `render-frame` em 5 ou 6 momentos-chave, Read em cada um, ajustar, `render` final (`--format prores --prores 4444` para alpha; Lottie: `exec file.exportLottie '{"comp":"Main","path":"nexus/saidas/x.json"}' P.ecproj`).

## 4. Vídeo, Reels e legendas (FilmCraft)

`filmcraft-cli --project P.fcproj --save exec <id> '<json>'`; import: `filmcraft-cli --save-as P.fcproj import a.mp4`; quadro: `filmcraft-cli --project P.fcproj render --seconds S --out f.png --scale 0.4`. Testado:

```bash
filmcraft-cli --save-as nexus/projetos/reels.fcproj import nexus/entrada/video.mp4          # → items [1]
filmcraft-cli --project nexus/projetos/reels.fcproj --save exec file.newSequence '{"name":"Reels","width":1080,"height":1920,"fps":30}'
filmcraft-cli --project nexus/projetos/reels.fcproj --save exec timeline.place '{"item":1,"track":"V1","seconds":0}'   # → clips [id]
filmcraft-cli --project nexus/projetos/reels.fcproj --save exec clip.fillFrame '{"clips":[<id>]}'
filmcraft-cli --project nexus/projetos/reels.fcproj exec file.exportMedia '{"path":"nexus/saidas/reels.mp4","format":"h264","burnCaptions":true,"captionSidecar":"srt","loudnessLufs":-14,"wait":true}'
```

**Transcrição**: a versão oficial não traz Whisper, e aqui os modelos não podem ser baixados. Faça assim:
1. Transcreva o áudio com timestamps por palavra usando o conector da ElevenLabs (`creative_transcribe_audio`; siga as instruções do conector para subir o arquivo). Sem conector, peça um `.srt` e use `captions.import {"path"}`.
2. Converta para o formato do FilmCraft (tempo em ticks: **254016000000 por segundo**) e importe no item de mídia com áudio:
   `exec transcript.set '{"item":1,"transcript":{"language":"pt","speakers":[{"name":"Locutor"}],"words":[{"text":"Olá","start":<ticks>,"end":<ticks>,"speaker":0},...]}}'`
3. Corte: `transcript.removeFillers {"fillers":["hã","hum","humm","ahn","ãh","éé","uh","um"]}` (nunca "é"; "né", "tipo" e "então" só se o usuário pedir) e, para ritmo acelerado, `transcript.removePauses {"minSeconds":0.6,"keepSeconds":0.12}`.
4. Legendas: `transcript.createCaptions` com `{"maxChars":12,"lines":1,"maxSeconds":0.8}` (estilo viral) ou `{"maxChars":28,"lines":2,"maxSeconds":2.5}` (clean). Corrija termos com `captions.list` + `captions.setText {"caption","text"}`. Estilo: `captions.setStyle {"track":"C1","size":90,"color":"#ffffff","outline":6,"outlineColor":"#000000","anchor":"bottom","margin":0.22}` (`describe captions.setStyle` para as opções).
5. Renderize 3 ou 4 quadros, olhe, exporte e informe quanto o vídeo encolheu.

## 5. Flyers e criativos (PhotoCraft)

`photocraft-cli run (<arquivo> | --new '<json>') --cmd <id> --params '<json>' ... --out saida.png`. Testado:

```bash
photocraft-cli run --new '{"width":1080,"height":1350,"background":"#120a24"}' \
  --cmd type.create --params '{"text":"OFERTA NEXUS","size":120,"color":"#ffffff","x":120,"y":600}' \
  --cmd type.create --params '{"text":"R$ 49,90","size":160,"color":"#a855f7","x":120,"y":820}' \
  --out nexus/saidas/flyer.png
```

- PSD do usuário: `photocraft-cli info arte.psd` mostra as camadas (ids, tipos, textos, bounds). Trocar texto: `--cmd type.edit --params '{"layer":<id>,"text":"..."}'`. Trocar foto de smart object: `--cmd layer.smartObjects.replaceContents --params '{"layer":<id>,"path":"/abs/foto.jpg"}'`. Imagem nova: `file.placeEmbedded`.
- **Lote** (CSV com variáveis, igual ao Photoshop): `image.variables.define {"defs":[{"name","layer","type":"textReplacement|pixelReplacement|visibility"}]}`, `file.import.variableDataSets {"path":"dados.csv"}` (valores com vírgula entre aspas), `file.export.dataSetsAsFiles {"dir":"nexus/saidas/lote","format":"png","naming":"{name}"}`. Teste uma versão com `image.applyDataSet {"index":0}` antes do lote.
- Mesma ação em várias imagens: `photocraft-cli batch --actions acoes.json --in dir --out dir`.
- Entregue PNG/JPG. O PSD gravado pelo PhotoCraft nem sempre abre perfeito no Photoshop.

## 6. Entre apps

PSD → motion: `photocraft-cli run arte.psd --cmd file.export.layersToFiles --params '{"dir":"/abs/camadas","format":"png"}'`, depois `info` para os bounds de cada camada. No EffectCraft: comp do mesmo tamanho, `file.import` + `layer.addItem` em cada PNG na posição original, o último quadro igual à arte e as entradas animadas antes dele (zoom na data, logo reveal, CTA por último). Motion pronto → FilmCraft como intro ou overlay do Reels.

## 7. Limitações (avise só quando importar)

Apps em alpha: podem surgir bugs, e o resultado não é idêntico ao Adobe. Não abrem `.aep`/`.prproj`. Sem GPU aqui, o render é na CPU (cerca de 6 s para 2 s de vídeo 1080p a 60 fps). No Mac, o plugin Nexus Studio do Claude Code faz o mesmo com Whisper local.

---
name: nexus-studio
description: Guia geral do Nexus Studio (PhotoCraft, FilmCraft e EffectCraft via MCP). Use sempre que o pedido envolver criar ou editar foto, flyer, PSD, vídeo, Reels, legenda, corte, motion graphics, animação, intro, Lottie ou renderização com esses apps, e antes de usar as ferramentas MCP photocraft, filmcraft ou effectcraft.
---

# Nexus Studio: como trabalhar com os 3 apps

O Nexus Studio junta três apps open source (alpha) que o Claude controla por MCP:

| Servidor MCP | App | Equivale a | Use para |
|---|---|---|---|
| `photocraft` | PhotoCraft | Photoshop | abrir/editar PSD, flyers, criativos estáticos, trocar textos e fotos, criativos em lote, recortar sujeito, exportar PNG/JPG |
| `filmcraft` | FilmCraft | Premiere Pro | montar vídeo, cortes, transcrição (Whisper), remover "hã"/pausas, legendas, cor (Lumetri), exportar MP4 |
| `effectcraft` | EffectCraft | After Effects | motion graphics, intros, textos animados, keyframes, efeitos, 3D, Lottie, render MP4/ProRes/GIF |

Fluxos prontos (skills deste plugin):
- `/nexus-studio:motion` motion graphics no EffectCraft
- `/nexus-studio:reels-legendado` vídeo vertical com corte automático e legenda no FilmCraft
- `/nexus-studio:criativos-em-lote` variações de flyer/anúncio a partir de um PSD no PhotoCraft
- `/nexus-studio:psd-para-motion` anima um PSD (PhotoCraft exporta camadas, EffectCraft anima)
- `/nexus-studio:instalar` e `/nexus-studio:testar` instalação e diagnóstico

Se as ferramentas MCP `photocraft`, `filmcraft` ou `effectcraft` não aparecerem ou falharem ao conectar, os binários não estão instalados: use a skill `instalar`.

## Pastas

Tudo fica em `~/NexusStudio/` (o instalador cria):

- `entrada/` arquivos que o usuário traz (vídeos, fotos, logos, PSDs de clientes)
- `templates/` PSDs e projetos modelo reutilizáveis
- `projetos/` projetos editáveis salvos (`.ecproj`, `.fcproj`, `.pcraft`)
- `saidas/` entregas finais (MP4, PNG, JPG, SRT, Lottie)
- `marca/` identidade visual padrão (logo, `cores.txt`, `fontes.txt`)

Nome das entregas: `AAAA-MM-DD_<cliente-ou-marca>_<peca>_<formato>.<ext>`, por exemplo `2026-10-19_minhaloja_promo_1080x1920.mp4`. Sempre use caminhos absolutos (expanda `~` para o HOME real com `echo $HOME`).

O PhotoCraft só lê arquivos dentro do HOME e só grava dentro de `~/NexusStudio`. FilmCraft e EffectCraft não têm essa trava, mas siga as mesmas pastas.

## Regras de ouro

1. **Descubra antes de executar.** Os apps estão em alpha e os parâmetros mudam entre versões. Antes de usar um comando pela primeira vez na sessão, confirme id e parâmetros:
   - EffectCraft: `list_commands {filter}` e `describe_command {command}`
   - FilmCraft e PhotoCraft: `command_list {filter}` (traz `params` e se está habilitado agora)

   Parâmetro desconhecido é rejeitado com a lista dos aceitos: leia o erro e corrija, não chute de novo.
2. **Olhe o resultado.** Antes de exportar, renderize quadros e confira: `render_frame` (EffectCraft e FilmCraft) ou `doc_render_preview`/`render_preview` (PhotoCraft). Abra o PNG e avalie de verdade (enquadramento, legibilidade, cortes de texto, contraste). Corrija antes de renderizar o final.
3. **Salve cedo.** Salve o projeto editável em `~/NexusStudio/projetos/` a cada etapa importante.
4. **Entregue formatos de entrega**: MP4 H.264 para redes, PNG/JPG para imagens. O PhotoCraft ainda não grava PSD 100% compatível com o Photoshop, então PSD só como extra. `.aep` e `.prproj` não abrem nesses apps.
5. **Se um comando falhar**, diga o que falhou em uma linha, tente um caminho alternativo (outro comando, `run_script` no EffectCraft, `command_batch`) e só então peça ajuda.

## Padrão de qualidade

- Motion: 60 fps, motion blur ligado, cada elemento animado separadamente com easing (nada de movimento linear sem intenção), entradas escalonadas, acabamento extremamente profissional.
- Antes de criar um motion, **pergunte o assunto e o estilo de design** (veja a skill `motion`).
- Identidade visual: use a marca em `~/NexusStudio/marca/` (logo em PNG, `cores.txt` com os hex, `fontes.txt`). Se a pasta estiver vazia, peça uma vez o logo e as cores e salve lá. Peças de clientes usam a identidade do cliente: pergunte ou procure em `entrada/`.
- Formatos: Reels/Stories 1080x1920, feed 1080x1350 ou 1080x1080, horizontal 1920x1080.

## Pipeline entre apps

- Arte estática → motion: PhotoCraft (`doc_export_layers` em PNG com transparência) → EffectCraft (`execute_command file.import`, depois `layer.addItem`).
- Motion → vídeo: EffectCraft renderiza MP4 ou ProRes 4444 com alpha → FilmCraft (`media_import`) monta com o vídeo gravado, legenda e exporta.
- Thumbnail ou capa: EffectCraft `render_frame {path}` ou FilmCraft `render_frame` → PhotoCraft `doc_open` para finalizar.

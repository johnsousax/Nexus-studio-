---
name: reels-legendado
description: Edita vídeo falado no FilmCraft (Premiere open source) via MCP para Reels, TikTok, Shorts ou anúncio. Formata em vertical 1080x1920, transcreve em português com Whisper, remove hesitações e pausas, gera e estiliza legendas, queima no vídeo, normaliza o áudio e exporta MP4 + SRT. Use quando o usuário pedir corte, legenda, Reels, vídeo vertical, remover pausas ou transcrição.
argument-hint: "[caminho do vídeo]"
---

# Reels legendado no FilmCraft

Vídeo(s): `$ARGUMENTS` (se vazio, procure em `~/NexusStudio/entrada/` ou pergunte)

## 0. Pré-requisitos e perguntas

1. Rode `command_list {"filter":"transcript.generate"}`. Se vier desabilitado com "speech-to-text is not available in this build", a transcrição não está instalada: avise que é preciso rodar `/nexus-studio:instalar --legendas`. Enquanto isso, ofereça montar o vídeo sem legenda ou importar um `.srt` pronto (`captions.import`).
2. Pergunte só o que não estiver claro (uma chamada de AskUserQuestion):
   - **Corte**: só tirar hesitações ("hã", "é...") ou ritmo acelerado, removendo também pausas longas (jump cuts)?
   - **Estilo da legenda**: palavra por palavra grande no centro (estilo viral) · frase curta embaixo (clean) · com caixa de fundo.
   - **Marca**: cores da Nexus (padrão) ou do cliente.

## 1. Montagem (servidor `filmcraft`)

Confirme os parâmetros com `command_list {"filter":"<id>"}` antes do primeiro uso de cada comando.

1. `media_import {"paths":["/abs/video.mp4"]}` e anote o item id (`project_inspect` mostra).
2. Sequência vertical:
   - vídeo já vertical: `command_run file.newSequence {"name":"Reels","fromItem":<id>}`
   - vídeo horizontal: `command_run file.newSequence {"name":"Reels","width":1080,"height":1920,"fps":30}`, depois `command_run timeline.place {"item":<id>,"track":"V1","seconds":0}` e `command_run clip.fillFrame {"clips":[<clipId>]}` (preenche o quadro; confira o enquadramento com `render_frame` e ajuste a posição em Motion se cortar o rosto).
3. `sequence_inspect` para confirmar clipes, duração e trilhas.

## 2. Transcrição e corte

1. Modelo: `command_run transcript.models {}`. Prefira `whisper-small` para português (melhor precisão). Se não estiver instalado: `command_run transcript.downloadModel {"model":"whisper-small"}` (são algumas centenas de MB).
2. `command_run transcript.generate {"items":[<id>],"model":"whisper-small","language":"pt"}`. Se `pt` for recusado, veja os valores aceitos no erro (`auto` também serve).
3. `command_run transcript.inspect {}` e leia o texto. Anote nomes próprios ou termos errados para corrigir na legenda.
4. Hesitações: `command_run transcript.removeFillers {"fillers":["hã","hum","humm","ahn","ãh","éé","uh","um"]}`. **Nunca** inclua "é" (é verbo). Também não remova "né", "tipo" ou "então" sem perguntar: em português costumam ter sentido.
5. Se o usuário quis ritmo acelerado: `command_run transcript.removePauses {"minSeconds":0.6,"keepSeconds":0.12}`.
6. `sequence_inspect` e `render_frame` em 2 ou 3 pontos para conferir se nenhum corte ficou estranho.

## 3. Legendas

1. `command_run transcript.createCaptions {...}` conforme o estilo escolhido:
   - Viral (palavra por palavra): `{"maxChars":12,"lines":1,"maxSeconds":0.8}`
   - Clean (frase curta): `{"maxChars":28,"lines":2,"maxSeconds":2.5}`
2. Corrija os erros anotados: `command_run captions.list {}`, depois `captions.setText {"caption":<id>,"text":"..."}`.
3. Estilo: `command_run captions.setStyle {"track":"C1", ...}` com `size`, `color`, `outline`, `outlineColor`, `background`, `backgroundColor`, `align`, `anchor`, `margin`. Confira os valores aceitos com `command_list {"filter":"captions.setStyle"}`. Sugestões:
   - Viral: grande, branco com contorno preto grosso, `anchor` middle e margem que posicione um pouco abaixo do centro.
   - Clean: médio, branco, caixa de fundo preta semitransparente, `anchor` bottom com `margin` perto de 0.22 (acima da interface do Instagram).
   - Destaque de marca: troque `color` pela cor principal da marca.
4. `render_frame {"seconds":t}` em 3 ou 4 pontos e olhe: legenda dentro da área segura, legível, sem cobrir o rosto.

## 4. Extras opcionais

- Gancho na abertura: `graphics.newText` com a frase de impacto nos primeiros 2 s (confira os params).
- Cor: `effects.apply {"effect":"Lumetri Color"}` no clipe e ajustes leves de exposição, contraste e saturação.
- Intro ou vinheta animada: gere no EffectCraft (skill `motion`), importe com `media_import` e coloque na V2 ou no início.

## 5. Exportar

1. Salve o projeto: `command_run file.saveAs {"path":"<HOME>/NexusStudio/projetos/<nome>.fcproj"}`.
2. `command_run file.exportMedia {"path":"<HOME>/NexusStudio/saidas/<nome>_1080x1920.mp4","format":"h264","burnCaptions":true,"captionSidecar":"srt","loudnessLufs":-14,"wait":true}`
3. Se `offlineMedia` vier preenchido, algum arquivo sumiu: avise.
4. Entregue em poucas linhas: duração final contra a original (quanto foi cortado), caminho do MP4 e do `.srt`, e o que você corrigiu na transcrição.

---
name: testar
description: Diagnóstico e teste ponta a ponta do Nexus Studio. Verifica se os 3 servidores MCP respondem e produz uma peça de teste real em cada app (imagem, vídeo e motion). Use depois de instalar ou quando algo parecer quebrado.
---

# Testar o Nexus Studio

## 1. Diagnóstico rápido (Bash)

```bash
bash "${CLAUDE_PLUGIN_ROOT}/scripts/doctor.sh"
```

Se algum app falhar, mostre a linha de erro e o log citado (`~/.nexus-studio/doctor-<app>.log`) e sugira `/nexus-studio:instalar --forcar`.

## 2. Teste real pelas ferramentas MCP

Faça os três testes abaixo. Use `$HOME` real (rode `echo $HOME`) para montar os caminhos absolutos. Grave tudo em `~/NexusStudio/saidas/teste/` (crie a pasta).

**EffectCraft (motion)**
1. `get_state` (anote a versão).
2. `execute_command comp.new {"name":"Teste","width":1080,"height":1080,"frameRate":60,"duration":2}`
3. `execute_command layer.newText {"text":"NEXUS STUDIO","size":110,"fill":"#ffffff","name":"Titulo"}`
4. `add_keyframe {"layer":"Titulo","path":"transform/scale","keys":[{"time":0,"value":[0,0]},{"time":0.6,"value":[100,100]}],"interpolation":"easyEase"}`
5. Ligue o motion blur: `execute_command comp.setSwitch {"switch":"motionBlur","value":true}` e `execute_command layer.setSwitch {"layers":["Titulo"],"switch":"motionBlur","value":true}`.
6. `render_frame {"time":0.3,"max_side":540}` e olhe a imagem.
7. `execute_command renderQueue.add {"comp":"Teste","format":"h264","output":"<HOME>/NexusStudio/saidas/teste/teste-effectcraft.mp4"}` e `execute_command renderQueue.render {"wait":true}`.

**PhotoCraft (imagem)**
1. `doc_new {"width":1080,"height":1080,"background":"#0b0b14","name":"Teste"}`
2. `command_list {"filter":"type.create"}` para confirmar os parâmetros, depois `command_run type.create {"text":"NEXUS STUDIO","size":90,"color":"#ffffff","x":120,"y":540}`.
3. `doc_render_preview` e olhe.
4. `doc_export {"path":"<HOME>/NexusStudio/saidas/teste/teste-photocraft.png"}`.

**FilmCraft (vídeo)**
1. `media_import {"paths":["<HOME>/NexusStudio/saidas/teste/teste-effectcraft.mp4"]}`
2. `command_run file.newSequence {"name":"Teste","width":1080,"height":1080,"fps":30,"fromItem":<id>}` (o id vem do import ou de `project_inspect`).
3. `command_run timeline.place {"item":<id>,"track":"V1","seconds":0}` caso o clipe ainda não esteja na timeline (confira com `sequence_inspect`).
4. `render_frame {"seconds":1}` e olhe.
5. `command_run file.exportMedia {"path":"<HOME>/NexusStudio/saidas/teste/teste-filmcraft.mp4","format":"h264","wait":true}`
6. `command_list {"filter":"transcript.generate"}`: informe se a transcrição automática está habilitada.

Se um passo falhar por causa de parâmetro, use o erro (ele lista os parâmetros aceitos) ou `describe_command`/`command_list`, corrija e continue. Anote cada correção.

## 3. Relatório

Entregue uma tabela curta: app, versão, ok/falha, arquivo gerado. Mostre o caminho da pasta `saidas/teste`. Se descobriu parâmetros diferentes dos escritos nas skills, liste-os para o usuário.

---
name: motion
description: Cria motion graphics profissionais no EffectCraft (After Effects open source) via MCP, como intros, vinhetas, textos animados, motion flyers, anúncios animados, lower thirds e logo reveals, a 60 fps com motion blur, e renderiza MP4, ProRes com alpha, GIF ou Lottie. Use quando o usuário pedir vídeo animado, motion, animação de texto/logo ou intro.
argument-hint: "[assunto do motion]"
---

# Motion graphics no EffectCraft

Pedido: `$ARGUMENTS`

## 0. Antes de criar: sempre pergunte

Pergunte com AskUserQuestion, numa única chamada, o que ainda não estiver claro no pedido:

1. **Assunto e texto**: o que o motion comunica (produto, oferta, evento, data, CTA) e os textos exatos.
2. **Estilo de design**, com opções como: Minimal clean (Apple-like) · Bold/tipográfico cinético · Neon/tech (roxo, azul, preto) · Festa/evento (flyer animado) · Corporativo elegante.
3. **Formato e duração**: Reels/Stories 1080x1920 · Feed 1080x1350 · Quadrado 1080x1080 · Horizontal 1920x1080; 6 s, 10 s ou 15 s.
4. **Marca**: a sua (padrão, em `~/NexusStudio/marca/`) ou a de um cliente (logo e cores em `~/NexusStudio/entrada/`).

Não comece a construir sem assunto e estilo definidos.

## 1. Roteiro antes dos keyframes

Escreva um roteiro curto (mostre ao usuário em 5 a 10 linhas) com cenas, tempos e o papel de cada elemento. Exemplo para 8 s:

| Tempo | Cena | Elementos e animação |
|---|---|---|
| 0.0-1.2 | Abertura | fundo com gradiente que respira, shape que varre a tela |
| 1.0-3.5 | Headline | palavras entram uma a uma (escala 80→100 + opacidade + leve blur→0), escalonadas 0.08 s |
| 3.5-6.0 | Oferta | preço com punch de escala (overshoot), destaque com glow |
| 6.0-8.0 | CTA + logo | logo reveal com máscara/escala, CTA desliza, fade final |

Hierarquia: o que o olho deve ver primeiro anima primeiro e com mais energia.

## 2. Montagem (ferramentas MCP do servidor `effectcraft`)

Confirme parâmetros com `describe_command` na primeira vez em que usar um comando.

1. **Composição a 60 fps**
   `execute_command comp.new {"name":"Main","width":1080,"height":1920,"frameRate":60,"duration":8}`
2. **Motion blur** (padrão obrigatório)
   - `execute_command comp.setSwitch {"switch":"motionBlur","value":true}`
   - `execute_command comp.settings {"shutterAngle":180,"shutterPhase":-90}` (confirme os nomes com `describe_command comp.settings`)
   - em cada layer animado: `execute_command layer.setSwitch {"layers":[...],"switch":"motionBlur","value":true}`
3. **Elementos**: dê sempre um `name` a cada layer.
   - Texto: `execute_command layer.newText {"text":"...","size":120,"fill":"#ffffff","name":"Headline"}`; fonte com `list_fonts {"query":"..."}` e depois `execute_command layer.setText {"layer":"Headline","font":"<family>","style":"Bold"}`; estilo por trecho com `range`.
   - Shapes: `execute_command layer.newShape {"kind":"rect|ellipse|...","name":"..."}`, e `layer.addShapeItem` para trim paths, repeater, round corners e gradiente.
   - Sólidos e fundos: `layer.newSolid {"color":"#...","name":"Fundo"}`; gradiente com `add_effect {"effect":"Gradient Ramp"}` ou fill de gradiente no shape.
   - Imagens e logo: `execute_command file.import {"paths":["/abs/logo.png"]}`, depois `execute_command layer.addItem` (veja os params com `describe_command layer.addItem`).
   - Controle: `layer.newNull` para animar grupos e fazer parenting.
4. **Animação**, um elemento por vez:
   - `add_keyframe {"layer":"Headline","path":"transform/scale","keys":[{"time":1.0,"value":[80,80]},{"time":1.5,"value":[100,100]}],"interpolation":"easyEase"}`
   - Curvas fortes estilo Flow: selecione as keys (`execute_command keys.select`) e use `execute_command keys.velocity {"outSpeed":0,"outInfluence":85}` / `inInfluence` entre 70 e 90.
   - Overshoot ou punch: três keys (100 → 112 → 100) ou expressão em `set_property {"expression":"..."}`.
   - Escalonamento: desloque cada elemento entre 0.06 e 0.12 s (`layer.timing` ou `layer.quickOffset`).
   - Para muitos elementos parecidos, use `run_script` com loops (`app.run(id, params)`) dentro de `app.beginUndoGroup()`/`endUndoGroup()`, ou `batch` com `$N.layer`.
5. **Efeitos de acabamento** (`list_effects {"filter":"..."}` → `add_effect`): Glow em destaques, Gaussian Blur animado em entradas, Drop Shadow sutil, Fractal Noise ou grain leve para textura, CC Light Sweep em logos.

## 3. Checagem visual (obrigatória)

- `render_frame {"time":t,"max_side":720}` em 5 ou 6 momentos-chave: começo, meio e fim de cada cena. Olhe cada imagem.
- Confira legibilidade, margens seguras (Reels: nada essencial nos 250 px de cima nem nos 350 px de baixo), contraste, texto cortado e elementos parados demais.
- Ajuste e renderize os quadros de novo. Mostre ao usuário 2 ou 3 quadros antes do render final, se ele estiver acompanhando.

## 4. Salvar e renderizar

1. `save_project {"path":"<HOME>/NexusStudio/projetos/<nome>.ecproj"}`
2. MP4 para redes:
   `execute_command renderQueue.add {"comp":"Main","format":"h264","output":"<HOME>/NexusStudio/saidas/<nome>.mp4"}` → `execute_command renderQueue.render {"wait":true}`
3. Extras, se pedidos:
   - Com transparência: `format: "prores"`, `channels: "rgba"`, `proresProfile: "4444"` (`.mov`)
   - GIF: `format: "gif"`
   - Lottie para sites e apps: `execute_command file.exportLottie {"comp":"Main","path":"<HOME>/NexusStudio/saidas/<nome>.json"}`. Leia os `warnings`: efeitos e blur não vão para o Lottie.
4. Confira o arquivo final: importe de volta (`file.import`) e faça `render_frame`, ou confira tamanho e duração com `ls -la`.

## 5. Entrega

Diga em uma ou duas linhas o que foi feito (estilo, duração, formato), o caminho do MP4 e o do projeto editável. Ofereça uma variação: outro formato, outra cor ou versão curta de 6 s.

## Template reutilizável (opcional)

Se o mesmo motion vai ser repetido para vários produtos ou clientes, transforme os textos, cores e imagens em controles de Essential Graphics (`essential.addProperty`), exporte o template (`essential.exportTemplate`) para `~/NexusStudio/templates/` e renderize cada variação pela CLI:

```bash
~/.nexus-studio/bin/effectcraft-cli render --template ~/NexusStudio/templates/promo.ectemplate \
  --values valores.json --out ~/NexusStudio/saidas/promo-produto1.mp4
```

`valores.json` é um objeto como `{"Titulo":"Tênis Runner","Preco":"R$ 49,90","Cor":"#7b2ff7"}`.

---
name: psd-para-motion
description: Transforma um flyer ou arte em PSD num motion animado. O PhotoCraft lê o PSD e exporta cada camada em PNG; o Claude analisa as camadas, cria um roteiro de animação (zoom na data, logo reveal, entrada do título etc.) e anima tudo no EffectCraft a 60 fps com motion blur. Use para motion flyer, flyer animado, animar arte pronta, intro a partir de PSD.
argument-hint: "[arte.psd]"
---

# PSD → motion flyer

Arquivo: `$ARGUMENTS` (se vazio, procure PSDs em `~/NexusStudio/entrada/` ou pergunte).

## 1. Ler e exportar o PSD (servidor `photocraft`)

1. `doc_open {"path":"/abs/arte.psd"}` → `doc_inspect`.
2. Anote cada camada visível: nome, tipo (texto, imagem, shape, grupo), bounds (x, y, largura, altura) e ordem. **Os bounds são essenciais para recolocar cada camada no mesmo lugar no EffectCraft.**
3. `doc_render_preview` e olhe a arte inteira.
4. Exporte as camadas em PNG com transparência:
   `doc_export_layers {"dir":"<HOME>/NexusStudio/projetos/<nome>-camadas","format":"png"}`
   Confira os arquivos gerados (`ls`) e relacione cada arquivo à sua camada. Se os PNGs vierem recortados no tamanho da camada, use os bounds anotados para posicioná-los; se vierem no tamanho da tela inteira, basta centralizar.
5. Exporte também a arte completa como referência: `doc_export {"path":"<HOME>/NexusStudio/projetos/<nome>-referencia.png"}`.

## 2. Roteiro automático

Com base nas camadas, proponha o roteiro (o usuário pode ajustar). Regras por tipo de peça:

- **Flyer de festa ou evento**: fundo com movimento lento constante (scale 100→108 em toda a duração), atração ou foto principal com entrada forte, nome do evento em impacto, **zoom e destaque na data**, local e horário entram depois, logo e patrocínios no final, CTA ("ingressos no link") por último.
- **Promoção ou oferta**: produto entra primeiro, depois o preço com punch e overshoot, selo de desconto girando ou pulsando, CTA.
- **Institucional**: logo reveal, slogan, informações, fechamento com o logo.

Antes de animar, pergunte o estilo se ainda não estiver claro (veja a skill `motion`) e confirme a duração e o formato.

## 3. Montar no EffectCraft (servidor `effectcraft`)

1. `execute_command comp.new` com o **mesmo tamanho do PSD**, `frameRate` 60, duração do roteiro.
2. Motion blur na comp e nos layers (como na skill `motion`).
3. `execute_command file.import {"paths":[...todos os PNGs...]}`; depois, para cada camada, de baixo para cima na ordem do PSD: `execute_command layer.addItem` (confira os params com `describe_command`), dê `name` igual ao do PSD e ajuste `transform/position` para o centro dos bounds originais: `[x + largura/2, y + altura/2]`.
4. `render_frame {"time":<fim>}` e compare com `<nome>-referencia.png`: o último quadro deve ficar idêntico à arte original. Corrija posições antes de animar.
5. Anime **de trás para a frente no tempo**: a pose final é a arte original, e as keys de entrada vêm antes dela. Para cada camada: keys de entrada (posição, escala, opacidade, blur) terminando na pose original, com `easyEase` e curvas fortes (`keys.velocity`, influence de 70 a 90), escalonadas de 0.06 a 0.12 s.
6. Siga os passos de checagem visual, salvamento e render da skill `motion` (render_frame em momentos-chave, `.ecproj` em `projetos/`, MP4 em `saidas/`).

## 4. Entrega

Mostre o roteiro aplicado em poucas linhas e entregue o MP4 e o projeto editável. Ofereça a versão 1080x1920 para Stories se o PSD for de outro formato.

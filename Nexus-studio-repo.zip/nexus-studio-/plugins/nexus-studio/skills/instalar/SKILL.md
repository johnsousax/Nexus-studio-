---
name: instalar
description: Instala ou atualiza os binários do Nexus Studio (photocraft-cli, filmcraft-cli, effectcraft-cli) no Mac. Use na primeira vez, quando os servidores MCP photocraft/filmcraft/effectcraft não conectarem, para ativar legendas automáticas (--legendas) ou para instalar os apps de desktop (--apps).
argument-hint: "[--legendas] [--apps] [--forcar] [--so app]"
---

# Instalar o Nexus Studio

Argumentos recebidos: `$ARGUMENTS`

## O que fazer

1. Explique em uma frase o que será instalado:
   - os CLIs oficiais assinados pela Apple, baixados das releases do GitHub (storytold/photocraft, filmcraft, effectcraft), em `~/.nexus-studio/bin`
   - a pasta de trabalho `~/NexusStudio`

2. Se o usuário não passou argumentos, pergunte uma vez (AskUserQuestion, múltipla escolha) se ele quer também:
   - **Legendas automáticas** (`--legendas`): compila o FilmCraft com Whisper. Leva de 10 a 30 minutos e instala Rust e as Command Line Tools da Apple se faltarem. Sem isso, a transcrição e a legenda automática do `reels-legendado` não funcionam.
   - **Apps de desktop** (`--apps`): PhotoCraft, FilmCraft e EffectCraft em /Applications, para abrir e ver/editar à mão.

3. Rode o instalador com a ferramenta Bash, **em segundo plano** quando houver `--legendas` (a compilação é longa), com timeout generoso:

   ```bash
   bash "${CLAUDE_PLUGIN_ROOT}/scripts/install.sh" $ARGUMENTS
   ```

   Ao final, o instalador roda o diagnóstico (`doctor.sh`) sozinho.

4. Se aparecer "Command Line Tools", uma janela da Apple abriu: peça para o usuário concluir a instalação nela e rode o instalador de novo.

5. Leia a saída e informe o resultado em poucas linhas: versão de cada app e se a transcrição ficou disponível.

6. Diga ao usuário para reconectar os servidores: digitar `/mcp` e reconectar `photocraft`, `filmcraft` e `effectcraft`, ou reiniciar o Claude Code. Depois disso, sugira `/nexus-studio:testar`.

## Problemas comuns

- **"nao consegui ler as releases no GitHub"**: limite da API do GitHub (60 por hora sem login). Espere alguns minutos ou rode com `GITHUB_TOKEN=<token>` na frente do comando.
- **Release sem CLI de macOS**: o instalador compila a partir do código-fonte automaticamente.
- **macOS bloqueou o binário ("não foi possível verificar o desenvolvedor")**: os binários oficiais são notarizados, mas a primeira execução consulta a Apple online. Com internet, rode de novo. Se persistir, rode `xattr -dr com.apple.quarantine ~/.nexus-studio/bin`.
- **Atualizar tudo**: `--forcar` reinstala a última versão de cada app.
